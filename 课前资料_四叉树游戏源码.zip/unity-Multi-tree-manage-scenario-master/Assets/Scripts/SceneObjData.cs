﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneObjData : MonoBehaviour
{
    public string resPath;   
}
